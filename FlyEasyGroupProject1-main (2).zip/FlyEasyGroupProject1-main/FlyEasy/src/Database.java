import java.util.ArrayList;

public class Database {

    public static ArrayList<UserList> getUserList(){
        return new ArrayList<UserList>();
    }
    public static ArrayList<FlightList> getFLights() {
        return new ArrayList<FlightList>();
    }
    public static ArrayList<airportList> getAirports(){
        return new ArrayList<airportList>();
    }
    public static ArrayList<HotelList> getHotels(){
        return new ArrayList<HotelList>();
    }

}
